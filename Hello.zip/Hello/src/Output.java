

public class Output {

    public static void main(String[] args) {

        System.out.print("Welcome to ");
        System.out.println("Java Programming");

        System.out.println("Welcome\n to\nJava\nProgramming");

        System.out.print("\tWelcome to\n");

        System.out.print("\rWelcome to");

        System.out.print(" Welcome to");

        System.out.print("\\ \"Welcome to\\n");

        System.out.printf("%s"," Welcome to");


    }
}
