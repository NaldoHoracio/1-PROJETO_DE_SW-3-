public class LocationTester {

    public static void main(String[] args) {

       SimpleLocation ic = new SimpleLocation();
       SimpleLocation ufal = new SimpleLocation(50, 60);

        System.out.println(ic.distance(ufal));

    }
}
