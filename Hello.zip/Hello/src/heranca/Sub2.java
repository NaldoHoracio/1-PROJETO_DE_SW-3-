package heranca;
public class Sub2 extends Person {

	public Sub2 (){
		
	}
	
	public void hello(String hello){
		System.out.println("Sub2");
	}
	
	public void teste( ){
		System.out.println("Teste Sub2");
	}
}
