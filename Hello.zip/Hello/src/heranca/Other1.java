package heranca;

public class Other1  {

	public Other1() {
		// TODO Auto-generated constructor stub
		Person person = new Person();
		person.y = "";
	}

}
