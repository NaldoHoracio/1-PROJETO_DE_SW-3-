package heranca;

public interface A {

	int converte(String x);
}
