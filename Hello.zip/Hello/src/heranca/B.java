package heranca;

public interface B {

	String converte (int x);
}
