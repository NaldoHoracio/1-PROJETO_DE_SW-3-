package heranca;

public interface C extends A, B {
	
}
