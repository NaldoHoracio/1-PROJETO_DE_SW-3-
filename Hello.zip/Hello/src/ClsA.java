
public class ClsA {
	
	int x;
	int y;
	
	public final void opA1(int a) {}
	public final void opA2(float b) {}
	public final void opA3(int a, String b) {}

	public ClsA() {
		// TODO Auto-generated constructor stub
	}

}
