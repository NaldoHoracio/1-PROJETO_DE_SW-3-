
public interface ltX {

	void op1(Object x);
	String op2(Object x, String y);
}
