public class MyClass{
    public static final int MY_VAR=27;
}