
public class SimpleLocation {

	public double latitude = 10;
	private double longitude;
	
	public SimpleLocation() {
		// TODO Auto-generated constructor stub
		this.latitude = 20;
		this.longitude = 30;
	}
	
	public SimpleLocation(double latitude, double longitude) {

		this.latitude = latitude;
		this.longitude = longitude;
	}

	public double distance(SimpleLocation other){
		System.out.println("Latitude "+this.latitude);
		System.out.println("Longitude: "+this.latitude);
		
		return this.latitude-other.latitude;
	}
	
	
}
