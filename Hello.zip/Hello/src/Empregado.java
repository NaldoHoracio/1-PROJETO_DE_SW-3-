
public class Empregado {

	public String nome = new String();
	public Empregado() {
		// TODO Auto-generated constructor stub
	}

}
