
public abstract class ClsB {

	
	String s1;
	int i;
	
	public ClsB() {
		// TODO Auto-generated constructor stub
	}
	
	public void opB1(String s){}
	public abstract void opB2(String s, String t) ;
	public void opB3(int a, int b) {}
	
	
}
