
public class Admin {
	String name = new String();
	public Admin() {
		a = 2;
	}
	
	public static int a;

	public static void main(String[] args) {
		
		int b = 2;
		
		a = 2;
	}
}
