
public class A {

	public A() {
		// TODO Auto-generated constructor stub
	}
	
	void metodo(int x) {
		System.out.println("x =" + (x-1));
	}
	
	

}
