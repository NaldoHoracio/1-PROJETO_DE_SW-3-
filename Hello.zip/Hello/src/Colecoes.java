
public class Colecoes {

	public Colecoes() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {
		
	}

}
