
public class B extends A {

	public B() {
		// TODO Auto-generated constructor stub
	}

	void metodo(int x) {
		super.metodo(x+1);
	}
	
	public static void main(String[] args) {
		A y = new B();
		y.metodo(5);
	}

}
