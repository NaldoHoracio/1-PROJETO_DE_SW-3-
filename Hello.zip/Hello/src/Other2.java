import heranca.Person;

public class Other2 {

	public Other2() {
		// TODO Auto-generated constructor stub
		Person person = new Person();
		
	}

}
